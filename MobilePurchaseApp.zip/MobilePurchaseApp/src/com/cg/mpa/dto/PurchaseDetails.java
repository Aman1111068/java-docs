package com.cg.mpa.dto;

import java.time.LocalDate;

public class PurchaseDetails 
{
	private String cname;
	private String mailid;
	private long phoneno;
	private long mobileid;
	private long purchaseid;
	private LocalDate purchaseDate;
	public PurchaseDetails() 
	{
		super();
		// TODO Auto-generated constructor stub
	}
	public PurchaseDetails(String cname, String mailid, long phoneno,
			long mobileid, long purchaseid, LocalDate purchaseDate) 
	{
		super();
		this.cname = cname;
		this.mailid = mailid;
		this.phoneno = phoneno;
		this.mobileid = mobileid;
		this.purchaseid = purchaseid;
		this.purchaseDate = purchaseDate;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public String getMailid() {
		return mailid;
	}
	public void setMailid(String mailid) {
		this.mailid = mailid;
	}
	public long getPhoneno() {
		return phoneno;
	}
	public void setPhoneno(long phoneno) {
		this.phoneno = phoneno;
	}
	public long getMobileid() {
		return mobileid;
	}
	public void setMobileid(long mobileid) {
		this.mobileid = mobileid;
	}
	public long getPurchaseid() {
		return purchaseid;
	}
	public void setPurchaseid(long purchaseid) {
		this.purchaseid = purchaseid;
	}
	public LocalDate getPurchaseDate() {
		return purchaseDate;
	}
	public void setPurchaseDate(LocalDate purchaseDate) {
		this.purchaseDate = purchaseDate;
	}
	@Override
	public String toString() {
		return "PurchaseDetails [cname=" + cname + ", mailid=" + mailid
				+ ", phoneno=" + phoneno + ", mobileid=" + mobileid
				+ ", purchaseid=" + purchaseid + ", purchaseDate="
				+ purchaseDate + "]";
	}
	

}

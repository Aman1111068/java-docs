package com.cg.mpa.dto;

public class Mobiles 
{
	private long mobileid;
	private String mobName;
	private double price;
	private int quantity;
	public Mobiles() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Mobiles(long mobileid, String mobName, double price, int quantity) {
		super();
		this.mobileid = mobileid;
		this.mobName = mobName;
		this.price = price;
		this.quantity = quantity;
	}
	public long getMobileid() {
		return mobileid;
	}
	public void setMobileid(long mobileid) {
		this.mobileid = mobileid;
	}
	public String getMobName() {
		return mobName;
	}
	public void setMobName(String mobName) {
		this.mobName = mobName;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	@Override
	public String toString() {
		return "Mobiles [mobileid=" + mobileid + ", mobName=" + mobName
				+ ", price=" + price + ", quantity=" + quantity + "]";
	}
	

}

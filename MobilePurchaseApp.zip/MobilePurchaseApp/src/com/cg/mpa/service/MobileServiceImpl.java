package com.cg.mpa.service;

import java.util.List;

import com.cg.mpa.dao.MobilePurchaseDao;
import com.cg.mpa.dao.MobilePurchaseDaoImpl;
import com.cg.mpa.dto.Mobiles;
import com.cg.mpa.dto.PurchaseDetails;
import com.cg.mpa.exceptions.MobileException;

public class MobileServiceImpl implements MobileService 
{
	MobilePurchaseDao mdao = new MobilePurchaseDaoImpl();

	@Override
	public List<Mobiles> getAllMobiles() throws MobileException 
	{
		
		return mdao.getAllMobiles();
	}

	@Override
	public Mobiles getMobile(long mid) throws MobileException 
	{
		
		return mdao.getMobile(mid);
	}

	@Override
	public long insertPurchaseDetails(PurchaseDetails pd)
			throws MobileException 
	{
		
		return mdao.insertPurchaseDetails(pd);
	}

	@Override
	public int updateMobileQty(long mid) throws MobileException 
	{
		
		
		return mdao.updateMobileQty(mid);
	}

}

package com.cg.mpa.dao;

public interface QueryMapper 
{
	String SELECT_ALL_MOBILES="SELECT * FROM MOBILES";
	String SELECT_MOBILE="SELECT * FROM MOBILES WHERE MOBILEID=?";
	String SELECT_SEQUENCE="SELECT purchase_seq.NEXTVAL FROM DUAL";
	String INSERT_QUERY="INSERT INTO purchasedetails Values(?,?,?,?,?,?)";
    String UPDATE_QUERY="Update mobiles set quantity=quantity-1 where mobileId=?";
}

package com.cg.mpa.dao;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.cg.mpa.exceptions.MobileException;

public class DBUtil 
{
	public static Connection conn;
	public static Connection getCon()throws MobileException
	{
		if(conn==null)
		{


			try {


				InitialContext context=new InitialContext();
				DataSource ds=(DataSource)context.lookup("java:/jdbc/OracleDS");
				conn=ds.getConnection();
			} 
			catch (NamingException e) 
			{

				throw new MobileException("Problem in obtaining Datasource:"+e.getMessage());
			}
			catch (SQLException e) 
			{

				throw new MobileException("Problem in obtaining connection from Datasource:"+e.getMessage());
			}
		}
		return conn;	


	}


}

package com.cg.mpa.dao;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.mpa.dto.Mobiles;
import com.cg.mpa.dto.PurchaseDetails;
import com.cg.mpa.exceptions.MobileException;

public class MobilePurchaseDaoImpl implements MobilePurchaseDao {
	Connection conn;
	@Override
	public List<Mobiles> getAllMobiles() throws MobileException 
	{
		List<Mobiles>mlist=new ArrayList<>();
		conn=DBUtil.getCon();
		try
		{
			Statement st=conn.createStatement();
			ResultSet rst=st.executeQuery(QueryMapper.SELECT_ALL_MOBILES);
			while(rst.next())
			{
				Mobiles m =new Mobiles();
				m.setMobileid(rst.getLong("mobileid"));
				m.setMobName(rst.getString("name"));
				m.setPrice(rst.getDouble("price"));
				m.setQuantity(rst.getInt("quantity"));
				mlist.add(m);

			}
		}
		catch(SQLException e)
		{
			throw new MobileException("Problem in fetching mobile list"+e.getMessage());
		}
		return mlist;
	}

	@Override
	public Mobiles getMobile(long mid) throws MobileException 
	{
		conn=DBUtil.getCon();
		Mobiles m=null;
		PreparedStatement pst;
		try {
			pst = conn.prepareStatement(QueryMapper.SELECT_MOBILE);
			pst.setLong(1, mid);
			ResultSet rst= pst.executeQuery();
			if(rst.next())
			{
				m= new Mobiles();
			m.setMobileid(rst.getLong("mobileid"));
			m.setMobName(rst.getString("name"));
			m.setPrice(rst.getDouble("price"));
			m.setQuantity(rst.getInt("quantity"));
			}
			else
			{
				throw new MobileException("Mobile not found");
			}
		}
		catch (SQLException e) 
		{
			throw new MobileException("Problem in fetching mobiles"+e.getMessage());
			
		}
		
		return m;
	}
	
	private long generatePurchaseId()throws MobileException
	{
		long pid=0;
		conn=DBUtil.getCon();
		try {
			Statement st=conn.createStatement();
			ResultSet rst=st.executeQuery(QueryMapper.SELECT_SEQUENCE);
			rst.next();
			pid=rst.getLong(1);
		} 
		catch (SQLException e) 
		{
			throw new MobileException("Problem in generating sequence for purchase id"+e.getMessage());
			
		}
		return pid;
	}
	

	@Override
	public long insertPurchaseDetails(PurchaseDetails pd)
			throws MobileException 
	{
		conn=DBUtil.getCon();
		PreparedStatement pst;
		pd.setPurchaseid(generatePurchaseId());
		try {
			pst = conn.prepareStatement(QueryMapper.INSERT_QUERY);
			pst.setLong(1,pd.getPurchaseid());
			pst.setString(2, pd.getCname());
			pst.setString(3, pd.getMailid());
			pst.setLong(4, pd.getPhoneno());
			pst.setDate(5, Date.valueOf(pd.getPurchaseDate()));
			pst.setLong(6, pd.getMobileid());
			pst.executeUpdate();
		} 
		catch (SQLException e) 
		{
			throw new MobileException("Problem in inserting mobile details"+e.getMessage());
			
		}
		return pd.getPurchaseid();
	}

	@Override
	public int updateMobileQty(long mid) throws MobileException 
	{
		conn=DBUtil.getCon();
		int dataUpdated;
		PreparedStatement pst;
		try
		{
			pst=conn.prepareStatement(QueryMapper.UPDATE_QUERY);
			pst.setLong(1,mid);
			dataUpdated=pst.executeUpdate();
		}
		catch(SQLException e)
		{
			throw new MobileException("Problem in updating mobile quantity"+e.getMessage());	
		}
		return dataUpdated;
	}

}

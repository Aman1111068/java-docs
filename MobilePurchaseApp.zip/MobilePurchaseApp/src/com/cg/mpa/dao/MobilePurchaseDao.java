package com.cg.mpa.dao;

import java.util.List;

import com.cg.mpa.dto.Mobiles;
import com.cg.mpa.dto.PurchaseDetails;
import com.cg.mpa.exceptions.MobileException;

public interface MobilePurchaseDao 
{
	List<Mobiles>getAllMobiles()throws MobileException;
	Mobiles getMobile(long mid)throws MobileException;
	long insertPurchaseDetails(PurchaseDetails pd)throws MobileException;
	int updateMobileQty(long mid) throws MobileException;

}

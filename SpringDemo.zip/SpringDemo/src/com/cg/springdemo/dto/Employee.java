package com.cg.springdemo.dto;

public class Employee 
{
	int empId;
	String empName;
	//Note: without getter function we can use because xml is providing the value
	//which is set in class but nothing we are getting in main class
	// so no getter is required.
	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public void getAllDetails()
	{
		System.out.println("employee Id is"+empId+"employee name is"+empName);
	}
    public void getData()
    {
    	System.out.println("Inside Get Data");
    }
}

package com.cg.springdemo.ui;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.springdemo.dto.Employee;
import com.cg.springdemo.dto.Shape;
//THIS PROGRAM WILL SHOW YOU THE LIFE CYCLE OF APPLICATION CONTEXT
public class MyTest {
	static Scanner sc=new Scanner(System.in);

	public static void main(String[] args) 
	{
		ApplicationContext app=new ClassPathXmlApplicationContext("spring.xml");
		System.out.println("Enter name of the Bean");
		String bean=sc.next();
          Shape sp=(Shape)app.getBean(bean);
          sp.getShape();
          //Shape sp2=(Shape)app.getBean("triangle");
         // Shape sp1=(Shape)app.getBean("circle");
          Employee emp=(Employee)app.getBean("emp");
          emp.getAllDetails();
          
	}

}

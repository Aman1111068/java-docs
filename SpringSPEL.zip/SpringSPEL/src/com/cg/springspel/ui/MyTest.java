package com.cg.springspel.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.springspel.dto.PrintEmpDetail;

public class MyTest 
{

	public static void main(String[] args) 
	{
		ApplicationContext app=new ClassPathXmlApplicationContext("spring.xml");
		PrintEmpDetail pr=(PrintEmpDetail) app.getBean("print");
          pr.getAllDetail();
	}

}

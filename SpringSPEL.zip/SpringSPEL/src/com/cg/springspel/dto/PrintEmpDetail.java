package com.cg.springspel.dto;

public class PrintEmpDetail 
{
	String fullName;
	double grossSalary;
	
	
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	public double getGrossSalary() {
		return grossSalary;
	}
	public void setGrossSalary(double grossSalary) {
		this.grossSalary = grossSalary;
	}
	
	public void getAllDetail()
	{
		System.out.println("Full Name "+fullName);
		System.out.println("Gross Salary "+grossSalary);
	}

}


public class TestAnimal 
{

	public static void main(String[] args) 
	{
		Animal obj=new Lion(2);
		obj.sound();

	}

}

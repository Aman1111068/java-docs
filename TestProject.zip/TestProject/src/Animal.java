
public abstract class Animal 
{
public abstract void sound();
public Animal(int a)
{
	System.out.println(a);
}

}

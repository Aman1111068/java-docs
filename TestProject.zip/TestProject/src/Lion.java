
public class Lion extends Animal 
{
public Lion(int a) 
{
		super(a);
		
	}

public void sound()
{
	System.out.println("roar");
}
}

package com.cg.springdemo3.service;

public interface IEmployeeService 
{
	public void getData(); 

}

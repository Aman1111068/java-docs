package com.cg.springdemo3.dto;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.springdemo3.service.IEmployeeService;

@Component("emp")
public class Employee 
{
	@Autowired
	IEmployeeService employeeservice;
 public void getDetails()
 {
	 System.out.println("Welcome to Spring Annotation...");
	 employeeservice.getData();
 }
}

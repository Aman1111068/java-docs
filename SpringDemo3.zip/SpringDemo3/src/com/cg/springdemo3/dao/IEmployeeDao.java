package com.cg.springdemo3.dao;

public interface IEmployeeDao 
{
	public void getData();

}

package com.cg.web;

import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.dto.User;
import com.cg.service.ControllerService;
import com.cg.service.ControllerServiceImpl;


@WebServlet("/ValidateServlet")
public class ValidateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       ControllerService conSer=null;
   User u=null;
    public ValidateServlet() {
        super();
        conSer=new ControllerServiceImpl();
        u=new User();
        // TODO Auto-generated constructor stub
    }

	
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
	}

	
	public void destroy() {
		// TODO Auto-generated method stub
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String fName=request.getParameter("name");
		String lName=request.getParameter("name1");
		String pass=request.getParameter("pass");
		char gen=request.getParameter("gender").charAt(0);
		
		String[] skill=request.getParameterValues("checkbox");
		String city=request.getParameter("city");
		int n=skill.length;
        String skl=skill[0];
        if(n==1)
        {
            skl=skill[0];
        }
        else
        {
            while(n>1)
            {
                skl=skl+" "+skill[n-1];
                n=n-1;
            }
        }
			
		
		u.setfName(fName);
		u.setlName(lName);
		u.setPassword(pass);
		u.setGender(gen);
		u.setSkill(skl);
		u.setCity(city);
		try {
			int dataAdded=conSer.insertUser(u);
			if(dataAdded==1)
			{
				response.sendRedirect("/Lab3.2WebProject/success.html");
			}
		   else
		{
			   response.sendRedirect("/Lab3.2WebProject/failure.html");
		}}
		catch (Exception e) {
			
			e.printStackTrace();
		}
		
	}

}

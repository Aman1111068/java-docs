package com.cg.service;

import com.cg.dto.User;

public interface ControllerService 
{
	public int insertUser(User u)throws Exception;

}

package com.cg.service;

import com.cg.dao.ControllerDao;
import com.cg.dao.ControllerDaoImpl;
import com.cg.dto.User;

public class ControllerServiceImpl implements ControllerService
{
   ControllerDao conDao=null;
   
	public ControllerServiceImpl() {
	super();
	conDao=new ControllerDaoImpl();
	// TODO Auto-generated constructor stub
}

	@Override
	public int insertUser(User u) throws Exception {
		
		return conDao.insertUser(u) ;
	}

}

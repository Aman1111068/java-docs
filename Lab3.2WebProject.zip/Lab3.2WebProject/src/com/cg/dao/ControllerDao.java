package com.cg.dao;

import com.cg.dto.User;

public interface ControllerDao 
{
	public int insertUser(User u)throws Exception;

}

package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;



import com.cg.dto.User;
import com.cg.util.DBUtil;


public class ControllerDaoImpl implements ControllerDao
{
	Connection con=null;
    PreparedStatement pst=null;
    ResultSet rs=null;
    User u=null;
	@Override
	public int insertUser(User u) throws Exception 
	{
		
	     con=DBUtil.getCon();
			System.out.println("Got Connection:");
			String qry="insert into RegisteredUsers(firstname,lastname,password,gender,skillset,city) values(?,?,?,?,?,?)";
			pst=con.prepareStatement(qry);
			 char gen= u.getGender();
			pst.setString(1,u.getfName() );
			pst.setString(2,u.getlName() );
			pst.setString(3, u.getPassword());
			pst.setString(4,String.valueOf(gen));
			pst.setString(5,u.getSkill());
			pst.setString(6,u.getCity());
			int dataAdded=pst.executeUpdate();
			return dataAdded;
		
		
	}
	

}

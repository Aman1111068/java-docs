package com.cg.springdemo2.dto;

import java.util.Iterator;
import java.util.List;

public class Employee implements EmployeeDetail 
{
 int empId;
 String empName;
 /*Project proOne;
 Project proTwo;*/
 List<Project> pro;
 
	
/*
	public int getEmpId() {
	return empId;
}



public void setEmpId(int empId) {
	this.empId = empId;
}



public String getEmpName() {
	return empName;
}



public void setEmpName(String empName) {
	this.empName = empName;
}



public Project getProOne() {
	return proOne;
}



public void setProOne(Project proOne) {
	this.proOne = proOne;
}



public Project getProTwo() {
	return proTwo;
}



public void setProTwo(Project proTwo) {
	this.proTwo = proTwo;
}
*/


	public Employee() {
	super();
	// TODO Auto-generated constructor stub
}



	@Override
	public void getAllEmployeeDetail() 
	{
		System.out.println("Id is "+empId);
		System.out.println("Name is "+empName);
		/*System.out.println("Project One Id is:"+proOne.getProjectId());
		System.out.println("Project One Name is:"+proOne.getProjectName());
		System.out.println("Project Two Id is:"+proTwo.getProjectId());
		System.out.println("Project Two Name is:"+proTwo.getProjectName());*/
	for(Project project : pro)
	{
		System.out.println("Project Id is:"+project.getProjectId());
		System.out.println("Project Name is:"+project.getProjectName());
	}
	
	
	}



	public int getEmpId() {
		return empId;
	}



	public void setEmpId(int empId) {
		this.empId = empId;
	}



	public String getEmpName() {
		return empName;
	}



	public void setEmpName(String empName) {
		this.empName = empName;
	}



	public List<Project> getPro() {
		return pro;
	}



	public void setPro(List<Project> pro) {
		this.pro = pro;
	}
	
	

}

package com.cg.springdemo2.dto;

public class Project 
{
	int projectId;
	String projectName;
	
	public int getProjectId() 
	{
		return projectId;
	}
	public void setProjectId(int projectId) 
	{
		this.projectId = projectId;
	}
	public String getProjectName() 
	{
		return projectName;
	}
	public void setProjectName(String projectName) 
	{
		this.projectName = projectName;
	}
	

}

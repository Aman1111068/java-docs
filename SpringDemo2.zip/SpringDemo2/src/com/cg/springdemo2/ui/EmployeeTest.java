package com.cg.springdemo2.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.springdemo2.dto.EmployeeDetail;

public class EmployeeTest 
{

	public static void main(String[] args) 
	{
		ApplicationContext app=new ClassPathXmlApplicationContext("springdemo2.xml");
        EmployeeDetail e=(EmployeeDetail) app.getBean("emp");
        e.getAllEmployeeDetail();
	}

}

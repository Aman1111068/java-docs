package com.cg.filter;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;

@WebFilter(filterName="AuthenticateFilter",urlPatterns={"/GreetServlet"})
public class AuthenticateFilter implements Filter {

    public AuthenticateFilter() {
        // TODO Auto-generated constructor stub
    }

	
	public void destroy() 
	{
		
	}

	
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		PrintWriter out=response.getWriter();
		String unm=request.getParameter("txtUName");
		
		String pwd=request.getParameter("txtPwd");
		if(unm.equals("aman")&&(pwd.equals("aman")))
		{
		chain.doFilter(request, response);
	}
		else
		{
			out.println("Sorry U r not allowed to go to greet servlet");
		}
	}

	
	public void init(FilterConfig fConfig) throws ServletException {
	
	}

}

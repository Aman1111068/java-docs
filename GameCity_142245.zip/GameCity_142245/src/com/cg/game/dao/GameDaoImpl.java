package com.cg.game.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.game.dto.GameBean;
import com.cg.game.dto.UserBean;
import com.cg.game.exception.GameException;



public class GameDaoImpl implements GameDao
{
	Connection conn;
	@Override
	public List<GameBean> getAllGames() throws GameException 
	{
		List<GameBean>glist=new ArrayList<>();
		conn=DBUtil.getCon();
		try
		{
			Statement st=conn.createStatement();
			ResultSet rst=st.executeQuery(QueryMapper.SELECT_ALL_GAMES);
			while(rst.next())
			{
				GameBean m =new GameBean();
				m.setName(rst.getString("name"));
				m.setAmount(rst.getInt("amount"));
				glist.add(m);
              
			}
		}
		catch(SQLException e)
		{
			throw new GameException("Problem in fetching mobile list"+e.getMessage());
		}
		return glist;

	}
	
	private int generateUserId()throws GameException
	{
		int pid=0;
		conn=DBUtil.getCon();
		try {
			Statement st=conn.createStatement();
			ResultSet rst=st.executeQuery(QueryMapper.SELECT_SEQUENCE);
			rst.next();
			pid=rst.getInt(1);
		} 
		catch (SQLException e) 
		{
			throw new GameException("Problem in generating sequence for purchase id"+e.getMessage());
			
		}
		return pid;
	}

	@Override
	public int insertuser(UserBean ub) throws GameException 
	{
		conn=DBUtil.getCon();
		PreparedStatement pst;
		ub.setUserId(generateUserId());
		try {
			pst = conn.prepareStatement(QueryMapper.INSERT_QUERY);
			pst.setInt(1,ub.getUserId());
			pst.setString(2, ub.getUserName());
			pst.setString(3, ub.getAddress());
			pst.setInt(4, ub.getCardAmount());
			
			pst.executeUpdate();
		} 
		catch (SQLException e) 
		{
			throw new GameException("Problem in inserting mobile details"+e.getMessage());
			
		}
		return ub.getUserId();
		
	}

	@Override
	public GameBean getGame(int amount) throws GameException 
	{
		conn=DBUtil.getCon();
		GameBean m=null;
		PreparedStatement pst;
		try {
			pst = conn.prepareStatement(QueryMapper.SELECT_Game);
			pst.setLong(1, amount);
			ResultSet rst= pst.executeQuery();
			if(rst.next())
			{
				m= new GameBean();
				m.setName(rst.getString("name"));
				m.setAmount(rst.getInt("amount"));
			}
			else
			{
				throw new GameException("Mobile not found");
			}
		}
		catch (SQLException e) 
		{
			throw new GameException("Problem in fetching mobiles"+e.getMessage());
			
		}
		
		return m;

		
	}


}

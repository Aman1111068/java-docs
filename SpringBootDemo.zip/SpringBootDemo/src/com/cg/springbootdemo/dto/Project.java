package com.cg.springbootdemo.dto;

import org.springframework.stereotype.Component;

@Component("proj")
public class Project 
{
	public void getData()
	{
		System.out.println("Welcome to Spring Boot");
	}

}

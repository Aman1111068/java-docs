package com.cg.springdemo4.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.springdemo4.dto.Employee;

public class MyTest 
{

	public static void main(String[] args) 
	{
		ApplicationContext app=new ClassPathXmlApplicationContext("spring.xml");
        Employee e=(Employee) app.getBean("emp1");
        e.getAllData();
	}

}

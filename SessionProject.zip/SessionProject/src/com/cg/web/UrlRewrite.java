package com.cg.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/UrlRewrite")
public class UrlRewrite extends HttpServlet {
	private static final long serialVersionUID = 1L;
       int count;
    ServletConfig cg=null;
    public UrlRewrite() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
		super.init(config);
		cg=config;
	}

	/**
	 * @see Servlet#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String iid=request.getParameter("id");
		if(iid==null)
		{
			iid="1";
		 count=Integer.parseInt(iid);
			count++;
		}
		else
		{
			count=Integer.parseInt(iid);
			count++;
		}
		PrintWriter pw=response.getWriter();
		pw.println("<b>I was Visited: "+count+"Times.<b>");
		pw.println("<br/>Do you want to visit me again ?");
		pw.println("<a href='/SessionProject/UrlRewrite?id="+count+"'>Click Here To Visit Again</a>");
	}

}

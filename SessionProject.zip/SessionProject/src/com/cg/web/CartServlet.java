package com.cg.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/CartServlet")
public class CartServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public CartServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
	}

	
	public void destroy() {
		// TODO Auto-generated method stub
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter pw=response.getWriter();
		String book=request.getParameter("txtBook");
		HttpSession session=request.getSession(true);
		ArrayList<String> bookList=(ArrayList)session.getAttribute("BookListObj");
		if(bookList==null)
		{
			bookList=new ArrayList<String>();
			bookList.add(book);
			session.setAttribute("BookListObj",bookList);
			
		}
		else
		{
			bookList.add(book);
			session.setAttribute("BookListObj",bookList);
		}
		pw.println("<br/>Is It a new Session?"+session.isNew());
		pw.println("<br/> Session id : "+session.getId());
		pw.println("<br/> Max Interval? : "+session.getMaxInactiveInterval());
		pw.println("<hr/>");
		pw.println("Items In Cart : "+bookList);
		pw.println("<br/>Do U want to Purchase again?");
		pw.print("<a href='/SessionProject/BookCatalogServlet'>Go To Home</a>");
	}

}

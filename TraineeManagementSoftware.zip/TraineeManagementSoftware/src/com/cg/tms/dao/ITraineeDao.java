package com.cg.tms.dao;

import java.util.List;

import com.cg.tms.dto.Trainee;



public interface ITraineeDao 
{
	public int addTraineeData(Trainee t);
	public void deleteTraineeData(int traineeId);
	public int updateTrainee(Trainee t);
	public List<Trainee> showAllTrainee();
	public List<Trainee> showTrainee(int traineeId);
	public Trainee searchTrainee(int traineeId);

}

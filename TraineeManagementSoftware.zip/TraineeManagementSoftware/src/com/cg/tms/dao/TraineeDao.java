package com.cg.tms.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.cg.tms.dto.Trainee;
@Repository("traineedao")
public class TraineeDao implements ITraineeDao {
@PersistenceContext
EntityManager entitymanager;
	@Override
	public int addTraineeData(Trainee t) 
	{
		System.out.println("In Dao Lyer"+t.getTraineeId());
		entitymanager.persist(t);
		entitymanager.flush();
		return 0;
	}

	@Override
	public void deleteTraineeData(int traineeId) 
	{
		

	}

	@Override
	public int updateTrainee(Trainee t) 
	{
		
		return 0;
	}

	@Override
	public List<Trainee> showAllTrainee() 
	{
		
		return null;
	}

	@Override
	public List<Trainee> showTrainee(int traineeId) 
	{
		
		return null;
	}

	@Override
	public Trainee searchTrainee(int traineeId) 
	{
		
		return null;
	}

}

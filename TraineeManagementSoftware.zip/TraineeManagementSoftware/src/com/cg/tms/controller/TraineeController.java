package com.cg.tms.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.tms.dto.Trainee;
import com.cg.tms.service.ITraineeService;

@Controller
public class TraineeController 
{
	@Autowired
	ITraineeService traineeservice;
	@RequestMapping(value="login",method=RequestMethod.GET)
	public String getAll(@RequestParam("uid") String username,@RequestParam("pwd") String password)
	{
		if(username.equalsIgnoreCase("Aman")&& password.equalsIgnoreCase("2696"))
		{
		return "tms";
		}
		return "error";
		
	}
	
	@RequestMapping(value="add",method=RequestMethod.GET)
	public String addTrainee(@ModelAttribute("my") Trainee t ,Map<String,Object> model)
	{
		List<String> myDeg=new ArrayList<>();
		myDeg.add("Please Enter Domain");
		myDeg.add("Java");
		myDeg.add("DotNet");
		myDeg.add("VnV");
		model.put("domain", myDeg);
		return "addTrainee";
	}
	
  @RequestMapping(value="insertdata",method=RequestMethod.POST)
	public String addTrainee(@ModelAttribute("my") Trainee t)
	{
	 int a=traineeservice.addTraineeData(t);
	 if(a==0)
	 {
		 return "tms"; 
	 }
		return "error";
	}
}

package com.cg.tms.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.tms.dao.ITraineeDao;
import com.cg.tms.dto.Trainee;
@Service("traineeservice")
@Transactional
public class TraineeService implements ITraineeService {
@Autowired
ITraineeDao traineedao;
	@Override
	public int addTraineeData(Trainee t) 
	{
		traineedao.addTraineeData(t);
		return 0;
	}

	@Override
	public void deleteTraineeData(int traineeId) 
	{
	
	}

	@Override
	public int updateTrainee(Trainee t) 
	{
		
		return 0;
	}

	@Override
	public List<Trainee> showAllTrainee() 
	{
		
		return null;
	}

	@Override
	public List<Trainee> showTrainee(int traineeId) 
	{
		
		return null;
	}

	@Override
	public Trainee searchTrainee(int traineeId) 
	{
		
		return null;
	}

}

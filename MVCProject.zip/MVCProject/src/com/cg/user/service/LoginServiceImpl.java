package com.cg.user.service;

import java.sql.SQLException;

import com.cg.user.dao.LoginDao;
import com.cg.user.dao.LoginDaoImpl;
import com.cg.user.dto.Login;
import com.cg.user.exception.LoginException;

public class LoginServiceImpl implements LoginService
{
LoginDao logDao=null;
	

	public LoginServiceImpl() {
		super();
		logDao= new LoginDaoImpl();
		// TODO Auto-generated constructor stub
	}


	
	public Login getUserByUnm(String unm) throws LoginException {
		// TODO Auto-generated method stub
		
		try {
			return logDao.getUserByUnm(unm);
		} catch (Exception e) {
		
			throw new LoginException(e.getMessage());
		}
	}

}

package com.cg.user.ctrl;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.user.dto.Login;
import com.cg.user.service.LoginService;
import com.cg.user.service.LoginServiceImpl;


@WebServlet("/LoginController")
public class LoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   ServletConfig cg=null;
   LoginService logSer=null;
    public LoginController() 
    {
        super();
       logSer=new LoginServiceImpl();
    }

	
	public void init(ServletConfig config) throws ServletException 
	{
		
		super.init(config);
		cg=config;
	}

	
	public void destroy() 
	{
		
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		
		doPost(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		String action=request.getParameter("action");
		HttpSession session=request.getSession(true);
		RequestDispatcher rd=null;
		
		if(action!=null)
		{
			
			try
			{
				/**************************ShowWelcomePage*************/
			if(action.equals("ShowWelcomePage"))
			{
				rd=request.getRequestDispatcher("/Pages/Welcome.jsp");
				rd.forward(request, response);
			}
			/**************************EndWelcomePage*****************/
			/**************************ShowLoginPage*************/
			if(action.equals("ShowLoginPage"))
			{
				rd=request.getRequestDispatcher("/Pages/Login.jsp");
				rd.forward(request, response);
			}
			/**************************EndLoginPage*************/
			/**************************ShowSuccessPage*************/
			if(action.equals("ShowSuccessPage"))
			{
				String unm=request.getParameter("txtUName");
				String pwd=request.getParameter("txtPwd");
				Login user=logSer.getUserByUnm(unm);
				if((user.getUserName().equalsIgnoreCase(unm))&&(user.getPassword().equalsIgnoreCase(pwd)))
				{
					session.setAttribute("UserNameObj", unm);
					RequestDispatcher rdSuccess=request.getRequestDispatcher("SuccessPage");
					rdSuccess.forward(request, response);
				}
				else
				{
					String msg="Sorry - Please check your password";
					request.setAttribute("ErrorMsgObj", msg);
					RequestDispatcher rdFailure=request.getRequestDispatcher("Pages/Login.jsp");
					rdFailure.forward(request, response);
				}
				
			}
			/**************************EndSuccessPage*************/
			}
		
		catch(Exception ee)
		{
			String errMsg=ee.getMessage();
			request.setAttribute("ErrorMsgObj",errMsg);
			RequestDispatcher rdError=request.getRequestDispatcher("ShowErrorPage");
			rdError.forward(request, response);
		}
			
		}
		else
		{
			response.getWriter().println("No action is specified");
		}
	}

}
